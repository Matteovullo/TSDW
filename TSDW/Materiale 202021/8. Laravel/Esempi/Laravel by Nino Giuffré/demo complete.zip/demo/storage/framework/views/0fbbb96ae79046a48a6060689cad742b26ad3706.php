<?php $__env->startSection('content'); ?>
    <h1>Projects Operations</h1>

    <form action="/projects/create" method="get">
        <input type="submit" value="Create Project"> <br><br><br>
    </form>

    <form action="/projects" method="get">
        <input type="submit" value="Show All Projects"> <br><br><br>
    </form>

    <form action="/projects/help_show" method="post">
        <?php echo csrf_field(); ?>
        <label for="id">Project ID </label> <br>
        <input type="number" name="id" id="id"> <br><br>
        <input type="submit" value="Search Project"> <br><br><br>
    </form>

    <form action="/projects" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Delete All Projects"> <br><br><br>
    </form>

    <h1>Tasks Operations</h1>

    <form action="/tasks/create" method="get">
        <input type="submit" value="Create Task"> <br><br><br>
    </form>

    <form action="/tasks" method="get">
        <input type="submit" value="Show All Tasks"> <br><br><br>
    </form>

    <form action="/tasks/help_show" method="post">
        <?php echo csrf_field(); ?>
        <label for="id">Task ID </label> <br>
        <input type="number" name="id" id="id"> <br><br>
        <input type="submit" value="Search Task"> <br><br><br>
    </form>

    <form action="/tasks" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Delete All Tasks">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/demo/resources/views/home.blade.php ENDPATH**/ ?>