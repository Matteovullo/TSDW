<?php $__env->startSection('content'); ?>
    <h1>Edit/Delete Task</h1>
    <form action="/tasks/<?php echo e($task->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <label for="title">Title</label> <br>
        <input type="text" name="title" id="title" value="<?php echo e($task->title); ?>"> <br><br>
        <label for="description">Description</label> <br>
        <textarea name="description" id="description" cols="30" rows="10"><?php echo e($task->description); ?></textarea> <br><br>
        <label for="project_id">Project ID</label> <br>
        <input type="number" name="project_id" id="project_id" value="<?php echo e($task->project_id); ?>"> <br><br>
        <input type="submit" value="Edit Task"> <br><br>
    </form>
    <form action="/tasks/<?php echo e($task->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Delete Task">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/demo/resources/views/tasks/edit.blade.php ENDPATH**/ ?>