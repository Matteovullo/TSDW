<?php $__env->startSection('content'); ?>
    <h1>Project <?php echo e($project->id); ?></h1>
    <b>TITLE:</b> <?php echo e($project->title); ?> <br>
    <b>DESCRIPTION:</b> <?php echo e($project->description); ?> <br>
    <?php if($project->tasks->count()): ?>
        <b>TASKS:</b>
        <ul>
            <?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <a href="/tasks/<?php echo e($task->id); ?>"><?php echo e($task->title); ?></a> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <br>
    <form action="/projects/<?php echo e($project->id); ?>/edit" method="get">
        <input type="submit" value="Edit/Delete Project"> <br><br>
    </form>
    <form action="/tasks/create" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="project_id" id="project_id" value="<?php echo e($project->id); ?>">
        <input type="submit" value="Create Task">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/demo/resources/views/projects/show.blade.php ENDPATH**/ ?>