<?php $__env->startSection('content'); ?>
    <h1>Create Project</h1>
    <form action="/projects" method="post">
        <?php echo csrf_field(); ?>
        <label for="title">Title</label> <br>
        <input type="text" name="title" id="title"> <br><br>
        <label for="description">Description</label> <br>
        <textarea name="description" id="description" cols="30" rows="10"></textarea> <br><br>
        <input type="submit" value="Create Project">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/demo/resources/views/projects/create.blade.php ENDPATH**/ ?>