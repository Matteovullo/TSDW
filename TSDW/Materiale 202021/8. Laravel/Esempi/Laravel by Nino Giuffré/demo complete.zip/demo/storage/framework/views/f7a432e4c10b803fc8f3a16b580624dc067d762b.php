<?php $__env->startSection('content'); ?>
    <h1>Edit/Delete Project</h1>
    <form action="/projects/<?php echo e($project->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <label for="title">Title</label> <br>
        <input type="text" name="title" id="title" value="<?php echo e($project->title); ?>"> <br><br>
        <label for="description">Description</label> <br>
        <textarea name="description" id="description" cols="30" rows="10"><?php echo e($project->description); ?></textarea> <br><br>
        <input type="submit" value="Edit Project"> <br><br>
    </form>
    <form action="/projects/<?php echo e($project->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Delete Project">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/demo/resources/views/projects/edit.blade.php ENDPATH**/ ?>